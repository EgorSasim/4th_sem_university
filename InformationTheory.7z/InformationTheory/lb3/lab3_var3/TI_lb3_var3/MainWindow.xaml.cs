﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TI_lb3_var3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SrcFileContent.Text = "";
            ResFileContent.Text = "";
            string valueStream = string.Empty;
            byte[] FileContent = File.ReadAllBytes(SrcFileInput.Text);
            BigInteger p = BigInteger.Parse(PInput.Text), q = BigInteger.Parse(QInput.Text);
            BigInteger n = BigInteger.Multiply(q, p);
            BigInteger b = BigInteger.Parse(BInput.Text);
            for (long i = 0; i < FileContent.Length; i++)
            {
                SrcFileContent.AppendText(FileContent[i].ToString() + " ");
                BigInteger c = BigInteger.Remainder(BigInteger.Multiply(FileContent[i], BigInteger.Add(FileContent[i], b)), n);
                valueStream += c.ToString() + " ";
            }
            ResFileContent.AppendText(valueStream);
            valueStream = valueStream.Remove(valueStream.Length - 1);
            File.WriteAllText(ResFileInput.Text, valueStream);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SrcFileContent.Text = "";
            ResFileContent.Text = "";
            List<byte> res = new List<byte>();
            BigInteger yp, yq;
            BigInteger p = BigInteger.Parse(PInput.Text), q = BigInteger.Parse(QInput.Text);
            BigInteger b = BigInteger.Parse(BInput.Text), n = BigInteger.Multiply(p, q);
            EuclidEx(p, q, out yp, out yq);
           // MessageBox.Show("Yp = " + yp.ToString() + " Yq = " + yq.ToString());
            int[] values = File.ReadAllText(SrcFileInput.Text).Split(' ').Select(Int32.Parse).ToArray();
            for (int i = 0; i < values.Length; i++)
            {
                SrcFileContent.AppendText(values[i].ToString() + " ");
                BigInteger D = BigInteger.Remainder(BigInteger.Add(BigInteger.Multiply(b, b), BigInteger.Multiply(4, values[i])), n);
                // MessageBox.Show("D = " + D.ToString());
                BigInteger Mp = BigInteger.Remainder(BigInteger.Pow(D, (int)BigInteger.Divide(BigInteger.Add(p, 1), 4)), p);
                BigInteger Mq = BigInteger.Remainder(BigInteger.Pow(D, (int)BigInteger.Divide(BigInteger.Add(q, 1), 4)), q);
                // MessageBox.Show("Mp = " + Mp.ToString() + " Mq = " + Mq.ToString());
                BigInteger[] d = new BigInteger[4];
                d[0] = BigInteger.Remainder((BigInteger.Add(BigInteger.Multiply(BigInteger.Multiply(yp, p), Mq), BigInteger.Multiply(BigInteger.Multiply(yq, q), Mp))), n);
                d[1] = BigInteger.Subtract(n, d[0]);
                d[2] = BigInteger.Remainder((BigInteger.Subtract(BigInteger.Multiply(BigInteger.Multiply(yp, p), Mq), BigInteger.Multiply(BigInteger.Multiply(yq, q), Mp))), n);
                d[3] = BigInteger.Subtract(n, (d[2]));
                for (int j = 0; j < d.Length; j++)
                {
                    //MessageBox.Show("d[" + (j + 1).ToString() + "] = " + d[j].ToString());
                    BigInteger m = BigInteger.Subtract(d[j], b);
                    if (BigInteger.Remainder(m, 2) == 0)
                    {
                        m = BigInteger.Remainder(BigInteger.Divide(m, 2), n);
                    }
                    else
                    {
                        m = BigInteger.Remainder(BigInteger.Divide(BigInteger.Add(m, n), 2), n);
                    }
                    if (m >= 0 && m <= 255)
                    {
                        res.Add((byte)m);
                        ResFileContent.AppendText(m.ToString() + " ");
                        break;
                    }
                }
            }
            File.WriteAllBytes(ResFileInput.Text, res.ToArray());
        }

        public static void EuclidEx(BigInteger p, BigInteger q, out BigInteger yp, out BigInteger yq)
        {
            BigInteger d0 = p, x0 = 1, y0 = 0;
            BigInteger d1 = q;
            BigInteger x1 = 0;
            BigInteger y1 = 1;
            while (d1 > 1)
            {
                BigInteger q1 = d0 / d1;
                BigInteger d2 = d0 % d1;
                BigInteger x2 = x0 - q1 * x1;
                BigInteger y2 = y0 - q1 * y1;
                d0 = d1;
                d1 = d2;
                x0 = x1;
                x1 = x2;
                y0 = y1;
                y1 = y2;
            }
            yq = y1;
            yp = x1;
        }
    }
}
