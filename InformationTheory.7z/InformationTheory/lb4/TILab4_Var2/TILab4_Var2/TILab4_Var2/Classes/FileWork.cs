﻿using System.Numerics;
using System.IO;


namespace TILab4_Var2.Classes
{
    public class FileWork
    {
        public static void WriteECPToFile(string pathToFile, string srcInfo, BigInteger r, BigInteger s)
        {
            File.WriteAllText(pathToFile, srcInfo + " " + r.ToString() + "," + s.ToString());
        }

        public static void GetECPFromFile(string pathToFile, out BigInteger r, out BigInteger s)
        {
            string[] fileContent = File.ReadAllText(pathToFile).Split(" ");
            string[] ecp = fileContent[fileContent.Length - 1].Split(",");
            r = BigInteger.Parse(ecp[0]);
            s = BigInteger.Parse(ecp[1]);
        }

        public static string GetSignedFileContent(string pathToFile)
        {
            string[] fileContent = File.ReadAllText(pathToFile).Split(" ");
            string result = string.Empty;
            for (int i = 0; i < fileContent.Length - 1; i++)
                result += fileContent[i];
            return result;
        }
    }
}
