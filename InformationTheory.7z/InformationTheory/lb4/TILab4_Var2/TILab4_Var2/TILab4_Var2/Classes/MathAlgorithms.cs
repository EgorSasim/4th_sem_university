﻿using System.Numerics;
using System.Windows;

namespace TILab4_Var2.Classes
{
    public class MathAlgorithms
    {
        public static BigInteger HashFunc(string src, BigInteger H0, BigInteger q)
        {
            BigInteger res = H0;
            for (int i = 0; i < src.Length; i++)
            {
                res = BigInteger.Remainder(BigInteger.Pow(BigInteger.Add(H0, src[i]), 2), q);
                H0 = res;
            }
            return res;
        }

        public static BigInteger FastExprModulo(BigInteger a, BigInteger b, BigInteger c)
        {
            BigInteger x = 1;
            while (b != 0)
            {
                while (b % 2 == 0)
                {
                    b = BigInteger.Divide(b, 2);
                    a = BigInteger.Multiply(a, a);
                    a = BigInteger.Remainder(a, c);
                }
                b = BigInteger.Subtract(b, 1);
                x = BigInteger.Multiply(x, a);
                x = BigInteger.Remainder(x, c);
            }
            return x;
        }

        public static bool IsPrime(BigInteger n)
        {
            int k = 100;
            if (n <= 100)
                k = (int)n - 1;
            for (int i = 2; i < k; i++)
            {
                BigInteger a = FastExprModulo(i, n - 1, n);
                if (a != 1)
                    return false;
            }
            return true;
        }

        public static bool CheckInput(BigInteger q, BigInteger p, BigInteger k, BigInteger h, BigInteger x)
        {
            if (!MathAlgorithms.IsPrime(q))
            {
                MessageBox.Show("q is not prime");
                return false;
            }
            if (!MathAlgorithms.IsPrime(p))
            {
                MessageBox.Show("p is not prime");
                return false;
            }
            if (BigInteger.Remainder(BigInteger.Subtract(p, 1), q) != 0)
            {
                MessageBox.Show("q is not a divider of p - 1");
                return false;
            }
            if (h <= 1 || h >= BigInteger.Subtract(p, 1))
            {
                MessageBox.Show("h value is not valid");
                return false;
            }
            if (x <= 0 || x >= q)
            {
                MessageBox.Show("x value is not valid");
                return false;
            }
            if (k <= 0 || k >= q)
            {
                MessageBox.Show("k value is not valid");
                return false;
            }
            return true;
        }
    }
}
