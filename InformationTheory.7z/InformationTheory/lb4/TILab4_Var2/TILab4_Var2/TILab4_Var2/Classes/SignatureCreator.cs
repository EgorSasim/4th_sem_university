﻿using System;
using System.Numerics;
using System.Windows;

namespace TILab4_Var2.Classes
{
    public class SignatureCreator
    {
        public static void CalculateECP(BigInteger p, BigInteger q, BigInteger h, BigInteger x, BigInteger k, BigInteger H0, string src, out BigInteger r, out BigInteger s, out BigInteger g, out BigInteger hash)
        {
            g = MathAlgorithms.FastExprModulo(h, BigInteger.Divide(BigInteger.Subtract(p, 1), q), p);
            if (g <= 1)
                throw new ArgumentException();
            hash = MathAlgorithms.HashFunc(src, H0, q);
            r = BigInteger.Remainder(MathAlgorithms.FastExprModulo(g, k, p), q);
            s = BigInteger.Remainder(BigInteger.Multiply(MathAlgorithms.FastExprModulo(k, BigInteger.Subtract(q, 2), q), BigInteger.Add(hash, BigInteger.Multiply(x, r))), q);
            if (r.Equals(0) || s.Equals(0))
                throw new Exception();
        }

        public static bool CheckECP(BigInteger p, BigInteger q, BigInteger h, BigInteger x, BigInteger H0, BigInteger r, BigInteger s, string src, out BigInteger g, out BigInteger y, out BigInteger v, out BigInteger hash, out BigInteger w, out BigInteger u1, out BigInteger u2)
        {
            hash = MathAlgorithms.HashFunc(src, H0, q);
            g = MathAlgorithms.FastExprModulo(h, BigInteger.Divide(BigInteger.Subtract(p, 1), q), p);
            if (g <= 1)
            {
                MessageBox.Show("g <= 1\nTry other value of h");
                throw new ArgumentException();
            }
            y = MathAlgorithms.FastExprModulo(g, x, p);
            w = MathAlgorithms.FastExprModulo(s, BigInteger.Subtract(q, 2), q);
            u1 = BigInteger.Remainder(BigInteger.Multiply(hash, w), q);
            u2 = BigInteger.Remainder(BigInteger.Multiply(r, w), q);
            v = BigInteger.Remainder(BigInteger.Remainder(BigInteger.Multiply(MathAlgorithms.FastExprModulo(g, u1, p), MathAlgorithms.FastExprModulo(y, u2, p)), p), q);
            return v.Equals(r);
        }
    }
}
