﻿using System.Windows;
using TILab4_Var2.Classes;
using System.IO;
using System.Numerics;
using System;

namespace TILab4_Var2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const int H0 = 100;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void SignFile(object sender, RoutedEventArgs e)
        {
            try
            {
                string srcFileContent = File.ReadAllText(FileToSignInput.Text);
                FileContent.Text = srcFileContent;
                BigInteger q = BigInteger.Parse(QInput.Text), p = BigInteger.Parse(PInput.Text), k = BigInteger.Parse(KInput.Text),
                           x = BigInteger.Parse(XInput.Text), h = BigInteger.Parse(HInput.Text);
                if (!MathAlgorithms.CheckInput(q, p, k, h, x))
                    return;
                BigInteger r, s, g, hash;
                SignatureCreator.CalculateECP(p, q, h, x, k, H0, srcFileContent, out r, out s, out g, out hash);
                FileWork.WriteECPToFile(ResFileInput.Text, srcFileContent, r, s);
                GOutput.Text = g.ToString();
                ROutput.Text = r.ToString();
                SOutput.Text = s.ToString();
                HashSignedOutput.Text = hash.ToString();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("g <= 1\nTry other h value");
            }
            catch (Exception ex)
            {
                if (ex is ArgumentNullException || ex is FileNotFoundException)
                    MessageBox.Show("File not found");
                else
                    MessageBox.Show("r or s == 0\nTry other k value");
            }
        }

        private void CheckFileSign(object sender, RoutedEventArgs e)
        {
            try
            {
                BigInteger q = BigInteger.Parse(QInput.Text), p = BigInteger.Parse(PInput.Text), k = BigInteger.Parse(KInput.Text),
                           x = BigInteger.Parse(XInput.Text), h = BigInteger.Parse(HInput.Text);
                if (!MathAlgorithms.CheckInput(q, p, k, h, x))
                    return;
                BigInteger r, s;
                BigInteger g, y, v, hash, u1, u2, w;
                FileWork.GetECPFromFile(FileToCheckSignInput.Text, out r, out s);
                string fileContent = FileWork.GetSignedFileContent(FileToCheckSignInput.Text);
                FileContent.Text = fileContent + " " + r.ToString() + "," + s.ToString();
                if (SignatureCreator.CheckECP(p, q, h, x, H0, r, s, fileContent, out g, out y, out v, out hash, out w, out u1, out u2))
                {
                    MessageBox.Show("Sign is valid");
                }
                else
                {
                    MessageBox.Show("Sign is invalid");
                }
                GOutput.Text = g.ToString();
                YOutput.Text = y.ToString();
                VOutput.Text = v.ToString();
                WOutput.Text = w.ToString();
                U1Output.Text = u1.ToString();
                U2Output.Text = u2.ToString();
                HashCheckSignOuptut.Text = hash.ToString();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("g <= 1\nTry other h value");
            }
            catch (Exception ex)
            {
                if (ex is ArgumentNullException || ex is FileNotFoundException)
                    MessageBox.Show("File not found");
            }
        }
    }
}
