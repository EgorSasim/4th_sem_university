﻿using System.Numerics;

class Tests
{
    static void Main()
    {
        const int H0 = 100;
        
        static BigInteger hashFunc(string src, BigInteger H0, BigInteger p, BigInteger q)
        {
            BigInteger n = BigInteger.Multiply(p, q);
            BigInteger res = H0;//BigInteger.Remainder(H0, n);
            
            for (int i = 0; i < src.Length; i++)
            {
                
                res = BigInteger.Remainder(BigInteger.Pow(BigInteger.Add(H0, src[i]), 2), n);
                Console.WriteLine("H{0} = ({1} + {2})^2 mod {3} = {4}", i+1, H0, Convert.ToInt16(src[i]), n, res);
                H0 = res;
            }
            return res;
        }



        Console.WriteLine("Write string");
        string? str = Console.ReadLine();
        Console.WriteLine("Write \"P\"");
        BigInteger? q = Convert.ToInt16(Console.ReadLine());
        Console.WriteLine("Write \"Q\"");
        BigInteger? p = Convert.ToInt16(Console.ReadLine());


        

        for (int i = 0; i < str.Length; i++)
        {
            Console.Write("{0}   ",str[i]);
        }
        Console.WriteLine();
        for (int i = 0; i < str.Length; i++)
        {
            Console.Write("{0}  ", Convert.ToInt16(str[i]));
        }
        Console.WriteLine();
        BigInteger hashFuncValue;
        hashFuncValue = hashFunc(str, H0, (BigInteger)p, (BigInteger)q);

        Console.WriteLine("\nHash function value: {0}", hashFuncValue);

        

    }
}