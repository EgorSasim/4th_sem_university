# OOTPISP_lab1
first lab work writing with C# language and WPF 
