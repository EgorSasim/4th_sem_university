﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace preLab4
{
    public interface ILogger
    {
        void WriteLine(string message);
    }
}
