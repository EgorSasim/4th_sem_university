﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace preLab4
{
    internal class NullLogger : ILogger
    {
        public void WriteLine(string message)
        {
            // Ничего не делаем в этой реализации
        }
    }
}
