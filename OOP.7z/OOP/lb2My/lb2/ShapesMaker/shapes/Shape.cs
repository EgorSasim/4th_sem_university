﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ShapesMaker
{
    public abstract class Shape
    {

        public abstract System.Windows.Shapes.Shape Draw();
    }
}
