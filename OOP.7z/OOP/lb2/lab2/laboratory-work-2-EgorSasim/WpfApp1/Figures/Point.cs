﻿namespace OOPLab2.Figures
{
    public class Point
    {
        internal protected int X { get; set; }
        internal protected int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
